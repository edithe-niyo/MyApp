@extends('layouts/app')

@section('content')
    <h1><?php echo $title;?> </h1>
    <p>this is about page of my app</p>
@endsection
